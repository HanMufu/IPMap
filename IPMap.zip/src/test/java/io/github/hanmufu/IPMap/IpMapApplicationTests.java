package io.github.hanmufu.IPMap;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class IpMapApplicationTests {

	@Test
	void contextLoads() {
	}

}
